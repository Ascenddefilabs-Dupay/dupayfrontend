import QRCodeComponent from './UserQr';

const QRCodePage: React.FC = () => {
    return (
        <div>
            <QRCodeComponent />
        </div>
    );
};

export default QRCodePage;
